#!/bin/sh
#
# uninstall.sh - remove the HP LaserJet 1020 driver from macOS.
#
#   sudo ./uninstall.sh               remove driver, daemon and print queue
#   sudo ./uninstall.sh --keep-queue  leave the print queue in place
#
set -u

PREFIX="/Library/Printers/HP1020"
LABEL="local.hp1020.fwloader"
KEEP_QUEUE=no
[ "${1:-}" = "--keep-queue" ] && KEEP_QUEUE=yes

[ "$(uname -s)" = Darwin ] || { echo "this script is for macOS" >&2; exit 1; }
[ "$(id -u)" = 0 ] || { echo "run it with sudo:  sudo sh ./uninstall.sh" >&2; exit 1; }

QUEUE="HP_LaserJet_1020"
if [ -r "$PREFIX/hp1020.conf" ]; then
    q=$(sed -n 's/^QUEUE="\{0,1\}\([A-Za-z0-9_-]*\)"\{0,1\}$/\1/p' "$PREFIX/hp1020.conf" | head -n 1)
    [ -n "$q" ] && QUEUE="$q"
fi

echo "==> stopping the firmware loader"
launchctl bootout "system/$LABEL" >/dev/null 2>&1 || true
rm -f "/Library/LaunchDaemons/$LABEL.plist"

if [ "$KEEP_QUEUE" = no ] && lpstat -p "$QUEUE" >/dev/null 2>&1; then
    echo "==> removing print queue $QUEUE"
    lpadmin -x "$QUEUE"
fi

echo "==> removing files"
rm -rf "$PREFIX"
rm -f "/Library/Printers/PPDs/Contents/Resources/HP-LaserJet-1020-arm64.ppd.gz"
[ -L /usr/local/bin/hp1020-tool ] && rm -f /usr/local/bin/hp1020-tool
rm -rf /var/db/hp1020 /Library/Logs/HP1020

echo "==> done"
