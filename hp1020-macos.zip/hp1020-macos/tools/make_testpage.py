#!/usr/bin/env python3
"""Build test/testpage.pdf: a two-page A4 test page for the HP LaserJet 1020.

Page 1 checks margins, gray levels, gradients, fine lines and text.
Page 2 checks multi-page jobs and alignment.
Requires reportlab and the DejaVu fonts (only needed to rebuild the PDF).
"""
import sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

out = sys.argv[1] if len(sys.argv) > 1 else "testpage.pdf"
FD = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("Sans", FD + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("SansB", FD + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Serif", FD + "DejaVuSerif.ttf"))
pdfmetrics.registerFont(TTFont("Mono", FD + "DejaVuSansMono.ttf"))

W, H = A4
M = 11.52 + 1.5  # frame 1.5 pt inside the 11.52 pt (4.06 mm) driver margin
c = canvas.Canvas(out, pagesize=A4)
c.setTitle("HP LaserJet 1020 test page")
c.setAuthor("hp1020-macos")

# ---------------- Page 1 ----------------
# Frame exactly on the printable area, plus a second frame 5 mm inside.
c.setLineWidth(0.5)
c.rect(M, M, W - 2 * M, H - 2 * M)
c.setDash(2, 2)
c.rect(M + 5 * mm, M + 5 * mm, W - 2 * M - 10 * mm, H - 2 * M - 10 * mm)
c.setDash()

# Corner marks: L shapes pointing into each corner of the paper
for (x, y, sx, sy) in [(M, M, 1, 1), (W - M, M, -1, 1), (M, H - M, 1, -1),
                       (W - M, H - M, -1, -1)]:
    c.setLineWidth(1.5)
    c.line(x, y, x + sx * 15 * mm, y)
    c.line(x, y, x, y + sy * 15 * mm)

x0, y = 22 * mm, H - 30 * mm
c.setFont("SansB", 22)
c.drawString(x0, y, "HP LaserJet 1020 — тестова страница")
y -= 9 * mm
c.setFont("Sans", 11)
c.drawString(x0, y, "macOS (Apple silicon) · CUPS · rastertozjs + foo2zjs · "
             "ZjStream")
y -= 6 * mm
c.drawString(x0, y, "Ако четете това, драйверът и фърмуерът работят.")
y -= 5 * mm
c.drawString(x0, y, "If you can read this, the driver and firmware work.")

# Gray step wedge 0..100 %
y -= 16 * mm
c.setFont("SansB", 11)
c.drawString(x0, y + 2 * mm, "Нива на сивото / Gray levels (0–100 %)")
y -= 14 * mm
bw = 15 * mm
for i in range(11):
    g = 1 - i / 10.0
    c.setFillGray(g)
    c.setStrokeGray(0)
    c.setLineWidth(0.3)
    c.rect(x0 + i * bw, y, bw, 12 * mm, stroke=1, fill=1)
    c.setFillGray(0)
    c.setFont("Sans", 7)
    c.drawCentredString(x0 + i * bw + bw / 2, y - 4 * mm, "%d%%" % (i * 10))

# Continuous gradient
y -= 22 * mm
c.setFont("SansB", 11)
c.drawString(x0, y + 2 * mm, "Плавен преход / Smooth gradient")
y -= 14 * mm
steps = 330
gw = 165 * mm / steps
for i in range(steps):
    c.setFillGray(i / (steps - 1.0))
    c.rect(x0 + i * gw, y, gw + 0.2, 12 * mm, stroke=0, fill=1)
c.setFillGray(0)

# Fine lines
y -= 14 * mm
c.setFont("SansB", 11)
c.drawString(x0, y, "Тънки линии / Line widths (pt)")
y -= 4 * mm
for i, lw in enumerate([0.1, 0.25, 0.5, 1, 2, 4]):
    yy = y - i * 6 * mm
    c.setLineWidth(lw)
    c.line(x0 + 20 * mm, yy, x0 + 120 * mm, yy)
    c.setFont("Sans", 8)
    c.drawString(x0, yy - 1, "%g pt" % lw)
# Hairline fan
cx, cy = x0 + 150 * mm, y - 15 * mm
c.setLineWidth(0.2)
for a in range(0, 91, 5):
    import math
    r = 18 * mm
    c.line(cx, cy, cx + r * math.cos(math.radians(a)),
           cy + r * math.sin(math.radians(a)))

# Text sizes, Latin and Cyrillic
y -= 46 * mm
c.setFont("SansB", 11)
c.drawString(x0, y, "Размери на шрифта / Font sizes")
y -= 4 * mm
for size in [5, 6, 8, 10, 12, 16, 24]:
    y -= size + 3
    c.setFont("Serif", size)
    txt = ("Шрифт ЖЩЮЯ — The quick brown fox 0123456789" if size < 16
           else "Шрифт ЖЩЮЯ — Fox 0123")
    c.drawString(x0, y, "%d pt  %s" % (size, txt))

y -= 10 * mm
c.setFont("Mono", 8)
c.drawString(x0, y, "Mono: AaBbCc 0O1lI| {}[]() #@&$% — Кирилица: абвгдежзий")

# Footer
c.setFont("Sans", 8)
c.drawString(x0, M + 12 * mm, "Външната рамка лежи по ръба на печатната област "
             "(около 4 мм от ръба на листа).")
c.drawString(x0, M + 8 * mm, "Всичките ѝ четири страни и ъгловите маркери "
             "трябва да се виждат на хартията.")
c.drawRightString(W - 22 * mm, M + 3 * mm, "Страница 1 / 2")
c.showPage()

# ---------------- Page 2 ----------------
c.setLineWidth(0.5)
c.rect(M, M, W - 2 * M, H - 2 * M)
c.setFont("SansB", 160)
c.drawCentredString(W / 2, H / 2 - 50, "2")
c.setFont("Sans", 14)
c.drawCentredString(W / 2, H / 2 - 90,
                    "Втора страница — многостраничен печат работи.")
c.drawCentredString(W / 2, H / 2 - 110,
                    "Page two — multi-page jobs work.")
# Crosshair in the middle for registration
c.setLineWidth(0.3)
c.line(W / 2 - 20 * mm, H - 40 * mm, W / 2 + 20 * mm, H - 40 * mm)
c.line(W / 2, H - 60 * mm, W / 2, H - 20 * mm)
c.circle(W / 2, H - 40 * mm, 10 * mm)
c.setFont("Sans", 8)
c.drawRightString(W - 22 * mm, M + 3 * mm, "Страница 2 / 2")
c.showPage()
c.save()
print("wrote", out)
