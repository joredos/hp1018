#!/usr/bin/env python3
"""Generate the PPD for the HP LaserJet 1020 macOS driver.

Paper sizes, foo2zjs paper codes and unprintable margins mirror the table in
src/rastertozjs.c (both come from foo2zjs-wrapper, model -z1).

Usage: gen_ppd.py [filter-path] > HP-LaserJet-1020-arm64.ppd
"""
import sys

FILTER = sys.argv[1] if len(sys.argv) > 1 else \
    "/Library/Printers/HP1020/Filter/rastertozjs"

# name, label, width pt, height pt, ulx, uly, lrx, lry (1200x600 dpi units)
PAPERS = [
    ("A4", "A4", 595, 842, 192, 96, 192, 96),
    ("Letter", "Letter", 612, 792, 192, 96, 192, 96),
    ("Legal", "Legal", 612, 1008, 192, 96, 192, 96),
    ("Executive", "Executive", 522, 756, 192, 96, 192, 96),
    ("A5", "A5", 420, 595, 192, 96, 192, 96),
    ("A6", "A6", 297, 420, 174, 78, 173, 78),
    ("B5", "B5 (JIS)", 516, 729, 192, 96, 192, 96),
    ("ISOB5", "B5 (ISO)", 499, 709, 192, 96, 192, 96),
    ("Env10", "Envelope #10", 297, 684, 171, 78, 171, 78),
    ("EnvDL", "Envelope DL", 312, 624, 176, 84, 176, 84),
    ("EnvC5", "Envelope C5", 459, 649, 170, 80, 169, 80),
    ("EnvMonarch", "Envelope Monarch", 279, 540, 174, 78, 173, 78),
    ("Postcard", "Postcard", 283, 420, 126, 87, 126, 87),
    ("DoublePostcardRotated", "Double Postcard (rotated)", 420, 567,
     126, 87, 126, 87),
    ("w558h774", "16K 197x273 mm", 558, 774, 192, 96, 192, 96),
    ("FanFoldGermanLegal", "German Legal Fanfold", 612, 936, 192, 96, 192, 96),
]


def fmt(v):
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return s


def area(w, h, ulx, uly, lrx, lry):
    left = ulx * 72.0 / 1200
    right = lrx * 72.0 / 1200
    top = uly * 72.0 / 600
    bottom = lry * 72.0 / 600
    return "%s %s %s %s" % (fmt(left), fmt(bottom), fmt(w - right),
                            fmt(h - top))


out = []
o = out.append
o('*PPD-Adobe: "4.3"')
o('*% HP LaserJet 1020 driver for macOS (Apple silicon, native arm64)')
o('*% Raster filter: rastertozjs + foo2zjs (GPL). Firmware loader: hp1020-fwd')
o('*FormatVersion: "4.3"')
o('*FileVersion: "1.0.0"')
o('*LanguageVersion: English')
o('*LanguageEncoding: ISOLatin1')
o('*PCFileName: "HPLJ1020.PPD"')
o('*Manufacturer: "HP"')
o('*Product: "(HP LaserJet 1020)"')
o('*ModelName: "HP LaserJet 1020"')
o('*ShortNickName: "HP LaserJet 1020 arm64"')
o('*NickName: "HP LaserJet 1020 (arm64, foo2zjs)"')
o('*1284DeviceID: "MFG:Hewlett-Packard;MDL:HP LaserJet 1020;CMD:ACL;"')
o('*PSVersion: "(3010.000) 0"')
o('*LanguageLevel: "3"')
o('*ColorDevice: False')
o('*DefaultColorSpace: Gray')
o('*FileSystem: False')
o('*Throughput: "14"')
o('*LandscapeOrientation: Plus90')
o('*TTRasterizer: Type42')
o('*cupsVersion: 2.2')
o('*cupsModelNumber: 1020')
o('*cupsManualCopies: True')
o('*cupsSNMPSupplies: False')
o('*cupsFilter: "application/vnd.cups-raster 0 %s"' % FILTER)
o('')

o('*OpenUI *ColorModel/Color Mode: PickOne')
o('*OrderDependency: 10 AnySetup *ColorModel')
o('*DefaultColorModel: Gray')
o('*ColorModel Gray/Grayscale: "<</cupsColorOrder 0/cupsColorSpace 0'
  '/cupsBitsPerColor 8/cupsCompression 0>>setpagedevice"')
o('*CloseUI: *ColorModel')
o('')

o('*OpenUI *Resolution/Resolution: PickOne')
o('*OrderDependency: 20 AnySetup *Resolution')
o('*DefaultResolution: 600dpi')
o('*Resolution 600dpi/600 dpi: "<</HWResolution[600 600]>>setpagedevice"')
o('*Resolution 1200x600dpi/FastRes 1200 (1200x600 dpi): '
  '"<</HWResolution[1200 600]>>setpagedevice"')
o('*CloseUI: *Resolution')
o('')

o('*OpenUI *PageSize/Media Size: PickOne')
o('*OrderDependency: 30 AnySetup *PageSize')
o('*DefaultPageSize: A4')
for name, label, w, h, *_ in PAPERS:
    o('*PageSize %s/%s: "<</PageSize[%d %d]/ImagingBBox null>>setpagedevice"'
      % (name, label, w, h))
o('*CloseUI: *PageSize')
o('')
o('*OpenUI *PageRegion/Media Size: PickOne')
o('*OrderDependency: 30 AnySetup *PageRegion')
o('*DefaultPageRegion: A4')
for name, label, w, h, *_ in PAPERS:
    o('*PageRegion %s/%s: "<</PageSize[%d %d]/ImagingBBox null>>'
      'setpagedevice"' % (name, label, w, h))
o('*CloseUI: *PageRegion')
o('')
o('*DefaultImageableArea: A4')
for name, label, w, h, ulx, uly, lrx, lry in PAPERS:
    o('*ImageableArea %s/%s: "%s"' % (name, label,
                                      area(w, h, ulx, uly, lrx, lry)))
o('')
o('*DefaultPaperDimension: A4')
for name, label, w, h, *_ in PAPERS:
    o('*PaperDimension %s/%s: "%d %d"' % (name, label, w, h))
o('')

o('*OpenUI *InputSlot/Media Source: PickOne')
o('*OrderDependency: 40 AnySetup *InputSlot')
o('*DefaultInputSlot: Auto')
o('*InputSlot Auto/Main Tray: "<</MediaPosition 7>>setpagedevice"')
o('*InputSlot Manual/Priority Slot (Manual Feed): '
  '"<</MediaPosition 4>>setpagedevice"')
o('*CloseUI: *InputSlot')
o('')

o('*OpenUI *MediaType/Media Type: PickOne')
o('*OrderDependency: 50 AnySetup *MediaType')
o('*DefaultMediaType: Plain')
for key, label in [("Plain", "Plain Paper"), ("Light", "Light (60-74 g/m2)"),
                   ("Heavy", "Heavy / Cardstock"), ("Rough", "Rough"),
                   ("Labels", "Labels"), ("Envelope", "Envelope"),
                   ("Transparency", "Transparency"),
                   ("Letterhead", "Letterhead"), ("Recycled", "Recycled")]:
    o('*MediaType %s/%s: "<</MediaType(%s)>>setpagedevice"'
      % (key, label, key))
o('*CloseUI: *MediaType')
o('')

o('*OpenGroup: HPQuality/Print Quality')
o('*OpenUI *HPDensity/Print Density: PickOne')
o('*OrderDependency: 60 AnySetup *HPDensity')
o('*DefaultHPDensity: 3')
for v, label in [("1", "1 (Lightest)"), ("2", "2"), ("3", "3 (Normal)"),
                 ("4", "4"), ("5", "5 (Darkest)")]:
    o('*HPDensity %s/%s: ""' % (v, label))
o('*CloseUI: *HPDensity')
o('')
o('*OpenUI *HPEconoMode/EconoMode (Toner Saving): Boolean')
o('*OrderDependency: 61 AnySetup *HPEconoMode')
o('*DefaultHPEconoMode: False')
o('*HPEconoMode False/Off: ""')
o('*HPEconoMode True/On: ""')
o('*CloseUI: *HPEconoMode')
o('')
o('*OpenUI *HPHalftone/Halftoning: PickOne')
o('*OrderDependency: 62 AnySetup *HPHalftone')
o('*DefaultHPHalftone: Clustered')
o('*HPHalftone Clustered/Clustered dot (best for laser): ""')
o('*HPHalftone ErrorDiffusion/Error diffusion (more detail in photos): ""')
o('*HPHalftone Threshold/Threshold (text only, no gray): ""')
o('*CloseUI: *HPHalftone')
o('*CloseGroup: HPQuality')
o('')

o('*DefaultFont: Courier')
for f in ["AvantGarde-Book", "AvantGarde-BookOblique", "AvantGarde-Demi",
          "AvantGarde-DemiOblique", "Bookman-Demi", "Bookman-DemiItalic",
          "Bookman-Light", "Bookman-LightItalic", "Courier", "Courier-Bold",
          "Courier-BoldOblique", "Courier-Oblique", "Helvetica",
          "Helvetica-Bold", "Helvetica-BoldOblique", "Helvetica-Narrow",
          "Helvetica-Narrow-Bold", "Helvetica-Narrow-BoldOblique",
          "Helvetica-Narrow-Oblique", "Helvetica-Oblique",
          "NewCenturySchlbk-Bold", "NewCenturySchlbk-BoldItalic",
          "NewCenturySchlbk-Italic", "NewCenturySchlbk-Roman",
          "Palatino-Bold", "Palatino-BoldItalic", "Palatino-Italic",
          "Palatino-Roman", "Symbol", "Times-Bold", "Times-BoldItalic",
          "Times-Italic", "Times-Roman", "ZapfChancery-MediumItalic",
          "ZapfDingbats"]:
    enc = "Special" if f in ("Symbol", "ZapfDingbats") else "Standard"
    o('*Font %s: %s "(001.000)" %s ROM' % (f, enc, enc))
o('')
o('*% End of PPD')

sys.stdout.write("\n".join(out) + "\n")
