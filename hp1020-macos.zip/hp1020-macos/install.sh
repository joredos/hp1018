#!/bin/sh
#
# install.sh - install the HP LaserJet 1020 driver on macOS (Apple silicon).
#
#   sudo ./install.sh                    build (if needed), install, create the
#                                        queue and start the firmware loader
#   sudo ./install.sh --firmware FILE    use your own sihp1020.dl / .img
#   sudo ./install.sh --no-queue         do not create the print queue
#   sudo ./install.sh --queue NAME       queue name (default HP_LaserJet_1020)
#   sudo ./install.sh --paper Letter     default paper size (default A4)
#
set -eu

cd "$(dirname "$0")"
TOP=$(pwd)

PREFIX="/Library/Printers/HP1020"
PPD_DIR="/Library/Printers/PPDs/Contents/Resources"
PPD_NAME="HP-LaserJet-1020-arm64.ppd.gz"
LABEL="local.hp1020.fwloader"
PLIST="/Library/LaunchDaemons/$LABEL.plist"
LOGDIR="/Library/Logs/HP1020"

say()  { printf '\n==> %s\n' "$*"; }
note() { printf '    %s\n' "$*"; }
fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

FIRMWARE_ARGS=""
MAKE_QUEUE=yes
QUEUE_NAME="HP_LaserJet_1020"
PAPER="A4"
while [ $# -gt 0 ]; do
    case "$1" in
        --firmware) [ $# -ge 2 ] || fail "--firmware needs a file"
                    FIRMWARE_ARGS="$2"; shift 2 ;;
        --no-queue) MAKE_QUEUE=no; shift ;;
        --queue)    [ $# -ge 2 ] || fail "--queue needs a name"; QUEUE_NAME="$2"; shift 2 ;;
        --paper)    [ $# -ge 2 ] || fail "--paper needs a size"; PAPER="$2"; shift 2 ;;
        -h|--help)  sed -n '3,11p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *)          fail "unknown option: $1" ;;
    esac
done

case "$QUEUE_NAME" in
    *[!A-Za-z0-9_-]*|"") fail "queue name may contain only letters, digits, _ and -" ;;
esac
case "$PAPER" in
    *[!A-Za-z0-9]*|"") fail "bad paper size '$PAPER'" ;;
esac
grep -q "^\*PageSize $PAPER/" "$TOP/ppd/HP-LaserJet-1020-arm64.ppd" \
    || fail "unknown paper size '$PAPER' (use A4, Letter, Legal, A5, A6, B5, Executive, EnvDL, ...)"

# ------------------------------------------------------------ preflight ----
[ "$(uname -s)" = Darwin ] || fail "this installer is for macOS"
[ "$(id -u)" = 0 ] || fail "run it with sudo:  sudo sh ./install.sh"
if [ "$(uname -m)" != arm64 ]; then
    note "warning: this Mac is $(uname -m), the driver is meant for Apple silicon (arm64); continuing"
fi
note "macOS $(sw_vers -productVersion 2>/dev/null || echo '?') on $(uname -m)"

# Files downloaded with a browser carry a quarantine flag; drop it here.
xattr -dr com.apple.quarantine "$TOP" 2>/dev/null || true

# ---------------------------------------------------------------- build ----
say "Building"
if [ -n "$FIRMWARE_ARGS" ]; then
    sh "$TOP/build.sh" --firmware "$FIRMWARE_ARGS"
else
    sh "$TOP/build.sh"
fi
for f in rastertozjs foo2zjs zjsdecode sihp1018.dl sihp1020.dl; do
    [ -s "$TOP/build/$f" ] || fail "build/$f is missing"
done

# -------------------------------------------------------------- install ----
say "Installing files"
# stop the old daemon first so it does not touch half-installed files
launchctl bootout "system/$LABEL" >/dev/null 2>&1 || true

install -d -m 755 -o root -g wheel "$PREFIX" "$PREFIX/Filter" "$PREFIX/bin" \
    "$PREFIX/Firmware" "$PREFIX/share"
install -m 755 -o root -g wheel "$TOP/build/rastertozjs" "$TOP/build/foo2zjs" "$PREFIX/Filter/"
install -m 755 -o root -g wheel "$TOP/build/zjsdecode" "$PREFIX/bin/"
install -m 755 -o root -g wheel "$TOP/scripts/hp1020-fwd" "$TOP/scripts/hp1020-tool" "$PREFIX/bin/"
install -m 644 -o root -g wheel "$TOP/scripts/hp1020-common.sh" "$PREFIX/bin/"
install -m 644 -o root -g wheel "$TOP/build/sihp1018.dl" "$TOP/build/sihp1020.dl" "$PREFIX/Firmware/"
install -m 644 -o root -g wheel "$TOP/test/testpage.pdf" "$TOP/README.md" "$PREFIX/share/"
install -m 644 -o root -g wheel "$TOP/src/foo2zjs/COPYING" "$PREFIX/share/COPYING.foo2zjs"

if [ -f "$PREFIX/hp1020.conf" ]; then
    note "keeping existing $PREFIX/hp1020.conf"
    # older versions pinned the 1020 firmware; switch to per-model selection
    if grep -q '^FIRMWARE=.*sihp1020\.dl' "$PREFIX/hp1020.conf"; then
        sed 's|^FIRMWARE=.*|FIRMWARE=""|' "$PREFIX/hp1020.conf" > "$PREFIX/hp1020.conf.new" \
            && mv "$PREFIX/hp1020.conf.new" "$PREFIX/hp1020.conf"
        note "firmware is now chosen by printer model (1018 / 1020)"
    fi
else
    install -m 644 -o root -g wheel "$TOP/scripts/hp1020.conf" "$PREFIX/hp1020.conf"
fi
# queue name in the config follows --queue
sed "s/^QUEUE=.*/QUEUE=\"$QUEUE_NAME\"/" "$PREFIX/hp1020.conf" > "$PREFIX/hp1020.conf.new" \
    && mv "$PREFIX/hp1020.conf.new" "$PREFIX/hp1020.conf" \
    && chown root:wheel "$PREFIX/hp1020.conf" && chmod 644 "$PREFIX/hp1020.conf"

for b in "$PREFIX/Filter/rastertozjs" "$PREFIX/Filter/foo2zjs" "$PREFIX/bin/zjsdecode"; do
    codesign --force --sign - "$b" >/dev/null 2>&1 || true
done
xattr -dr com.apple.quarantine "$PREFIX" 2>/dev/null || true

install -d -m 755 "$PPD_DIR"
sed "s/^\*DefaultPageSize: .*/*DefaultPageSize: $PAPER/; s/^\*DefaultPageRegion: .*/*DefaultPageRegion: $PAPER/; s/^\*DefaultImageableArea: .*/*DefaultImageableArea: $PAPER/; s/^\*DefaultPaperDimension: .*/*DefaultPaperDimension: $PAPER/" \
    "$TOP/ppd/HP-LaserJet-1020-arm64.ppd" | gzip -9 > "$PPD_DIR/$PPD_NAME"
chown root:wheel "$PPD_DIR/$PPD_NAME"
chmod 644 "$PPD_DIR/$PPD_NAME"

mkdir -p /usr/local/bin
ln -sf "$PREFIX/bin/hp1020-tool" /usr/local/bin/hp1020-tool
note "driver files in $PREFIX"
note "PPD: $PPD_DIR/$PPD_NAME"
note "command: hp1020-tool"

# ------------------------------------------------------- firmware daemon ----
say "Starting the firmware loader (LaunchDaemon $LABEL)"
install -d -m 755 -o root -g wheel "$LOGDIR"
[ -d /Library/LaunchDaemons ] || mkdir -p /Library/LaunchDaemons
install -m 644 -o root -g wheel "$TOP/launchd/$LABEL.plist" "$PLIST"
launchctl enable "system/$LABEL" 2>/dev/null || true

# launchd tears the old instance down asynchronously; bootstrapping too early
# fails with "5: Input/output error".  Wait until it is gone, then retry.
i=0
while launchctl print "system/$LABEL" >/dev/null 2>&1 && [ $i -lt 15 ]; do
    launchctl bootout "system/$LABEL" >/dev/null 2>&1 || true
    sleep 1
    i=$((i + 1))
done
DAEMON_OK=no
i=0
while [ $i -lt 8 ]; do
    launchctl bootstrap system "$PLIST" >/dev/null 2>&1 || true
    if launchctl print "system/$LABEL" 2>/dev/null | grep -q "state = running"; then
        DAEMON_OK=yes
        break
    fi
    sleep 2
    i=$((i + 1))
done
if [ "$DAEMON_OK" = yes ]; then
    note "firmware loader is running"
else
    note "WARNING: the firmware loader did not start."
    note "Allow 'hp1020-fwd' in System Settings > General > Login Items & Extensions > Allow in the Background, then run:"
    note "    sudo launchctl bootstrap system $PLIST"
fi
note "log: $LOGDIR/hp1020-fwd.log"

# ----------------------------------------------------------------- queue ----
if [ "$MAKE_QUEUE" = yes ]; then
    say "Creating the print queue $QUEUE_NAME"
    if "$PREFIX/bin/hp1020-tool" add-queue; then
        lpadmin -p "$QUEUE_NAME" -o PageSize="$PAPER" 2>/dev/null || true
    else
        note "The printer was not found on USB. Switch it on, connect it, then run:"
        note "    sudo hp1020-tool add-queue"
    fi
fi

# ---------------------------------------------------------- first check ----
say "Waiting for the firmware loader (up to 40 s)"
i=0
while [ $i -lt 40 ]; do
    if "$PREFIX/bin/hp1020-tool" status 2>/dev/null | grep -q "firmware: LOADED"; then
        break
    fi
    sleep 4
    i=$((i + 4))
done
"$PREFIX/bin/hp1020-tool" status || true

say "Done"
if [ "$DAEMON_OK" != yes ]; then
    note "!!! The firmware loader is NOT running: the printer will stop printing after it is switched off."
    note "!!! Fix: allow 'hp1020-fwd' in Login Items & Extensions, then: sudo launchctl bootstrap system $PLIST"
fi
note "Test without paper:   hp1020-tool test-dry"
note "Print the test page:  hp1020-tool test-print"
note "From any app: File > Print > 'HP LaserJet 1020'"
