/*
 * rastertozjs - CUPS raster to ZjStream filter for the HP LaserJet 1020
 *               (also 1018/1022) on macOS, native arm64.
 *
 * macOS renders every print job to CUPS raster with its own Quartz
 * rasterizer (cgpdftoraster).  This filter takes that raster, converts each
 * page to 1-bit black/white (with a clustered-dot screen, error diffusion or
 * a plain threshold), and pipes the pages as PBM into foo2zjs, which
 * produces the JBIG-compressed ZjStream the printer understands.
 *
 * Usage (as called by CUPS):
 *     rastertozjs job-id user title copies options [file]
 *
 * Copyright (C) 2026
 * License: GNU General Public License, version 2 or later (same as foo2zjs).
 */

#include <cups/cups.h>
#include <cups/raster.h>

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef FOO2ZJS_PATH
#define FOO2ZJS_PATH "/Library/Printers/HP1020/Filter/foo2zjs"
#endif

#define VERSION_STRING "rastertozjs 1.0"

/* ------------------------------------------------------------------------ */
/* Paper table.  Codes and unprintable margins come from foo2zjs-wrapper     */
/* for model -z1 (HP LaserJet 1018/1020/1022).  Margins are in 1200x600 dpi  */
/* units, exactly as the wrapper passes them to foo2zjs -u/-l.               */
/* ------------------------------------------------------------------------ */

typedef struct
{
  const char *name;
  int w_pt, h_pt;        /* paper size in PostScript points (portrait) */
  int code;              /* foo2zjs -p paper code for -z1 */
  int ulx, uly, lrx, lry;
  int xdim, ydim;        /* sheet size in 1200x600 dpi pixels (wrapper) */
} paper_t;

static const paper_t papers[] =
{
  { "Letter",                612,  792,   1, 192, 96, 192, 96, 10200, 6600 },
  { "Legal",                 612, 1008,   5, 192, 96, 192, 96, 10200, 8400 },
  { "Executive",             522,  756,   7, 192, 96, 192, 96, 8700, 6300 },
  { "A4",                    595,  842,   9, 192, 96, 192, 96, 9920, 7016 },
  { "A5",                    420,  595,  11, 192, 96, 192, 96, 6992, 4960 },
  { "B5",                    516,  729,  13, 192, 96, 192, 96, 8598, 6070 },
  { "ISOB5",                 499,  709, 259, 192, 96, 192, 96, 8316, 5904 },
  { "A6",                    297,  420, 262, 174, 78, 173, 78, 4956, 3498 },
  { "Env10",                 297,  684,  20, 171, 78, 171, 78, 4950, 5700 },
  { "EnvDL",                 312,  624,  27, 176, 84, 176, 84, 5200, 5200 },
  { "EnvC5",                 459,  649,  28, 170, 80, 169, 80, 7650, 5408 },
  { "EnvMonarch",            279,  540,  37, 174, 78, 173, 78, 4650, 4500 },
  { "Postcard",              283,  420, 260, 126, 87, 126, 87, 4728, 3498 },
  { "DoublePostcardRotated", 420,  567, 261, 126, 87, 126, 87, 6996, 4722 },
  { "w558h774",              558,  774, 257, 192, 96, 192, 96, 9306, 6448 },
  { "FanFoldGermanLegal",    612,  936, 258, 192, 96, 192, 96, 10200, 7800 },
  { NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};

static const paper_t custom_paper =
  { "Custom", 0, 0, 256, 192, 96, 192, 96, 0, 0 };

/* ------------------------------------------------------------------------ */
/* Halftoning                                                                */
/* ------------------------------------------------------------------------ */

enum { HT_CLUSTERED = 0, HT_DIFFUSION = 1, HT_THRESHOLD = 2 };

/*
 * 8x8 threshold array holding two clustered dots per tile, which gives a
 * 45-degree screen of about 106 lines per inch at 600 dpi: the classic
 * "clustered dot" screen used on laser printers.  Ranks 1..32 appear twice.
 */
static const unsigned char cluster_rank[8][8] =
{
  { 13,  7,  8, 14, 17, 21, 22, 18 },
  {  6,  1,  3,  9, 28, 31, 29, 23 },
  {  5,  2,  4, 10, 27, 32, 30, 24 },
  { 16, 12, 11, 15, 20, 26, 25, 19 },
  { 17, 21, 22, 18, 13,  7,  8, 14 },
  { 28, 31, 29, 23,  6,  1,  3,  9 },
  { 27, 32, 30, 24,  5,  2,  4, 10 },
  { 20, 26, 25, 19, 16, 12, 11, 15 }
};

static unsigned char cluster_thresh[8][8];

static void
init_cluster(void)
{
  int x, y;

  /* Pixel is black when gray < threshold.  Thresholds run from ~8 to ~247,
   * so pure black (0) is always black and pure white (255) never is. */
  for (y = 0; y < 8; y++)
    for (x = 0; x < 8; x++)
      cluster_thresh[y][x] =
          (unsigned char)((cluster_rank[y][x] * 255 + 16) / 33);
}

/* ------------------------------------------------------------------------ */
/* Options                                                                   */
/* ------------------------------------------------------------------------ */

typedef struct
{
  int media;        /* -m */
  int source;       /* -s */
  int density;      /* -T 1..5 */
  int econo;        /* -t */
  int halftone;
} job_opts_t;

/* Read "*DefaultName: Value" from the queue's PPD file (env PPD). */
static int
ppd_default(const char *ppdfile, const char *name, char *value, size_t vsize)
{
  FILE *fp;
  char line[512], key[128];
  size_t klen;
  int found = 0;

  if (!ppdfile || !*ppdfile || (fp = fopen(ppdfile, "r")) == NULL)
    return 0;

  snprintf(key, sizeof(key), "*Default%s:", name);
  klen = strlen(key);

  while (fgets(line, sizeof(line), fp))
  {
    if (strncmp(line, key, klen) == 0)
    {
      char *p = line + klen, *e;

      while (*p == ' ' || *p == '\t')
        p++;
      e = p + strlen(p);
      while (e > p && (e[-1] == '\n' || e[-1] == '\r' || e[-1] == ' '
                       || e[-1] == '\t'))
        *--e = '\0';
      snprintf(value, vsize, "%s", p);
      found = 1;
      break;
    }
  }
  fclose(fp);
  return found;
}

/* Job option first, then the queue default from the PPD, then fallback. */
static const char *
get_opt(const char *name, int num_options, cups_option_t *options,
        const char *ppdfile, char *buf, size_t bufsize, const char *fallback)
{
  const char *v = cupsGetOption(name, num_options, options);

  if (v && *v)
    return v;
  if (ppd_default(ppdfile, name, buf, bufsize))
    return buf;
  return fallback;
}

static int
is_true(const char *v)
{
  return v && (!strcasecmp(v, "true") || !strcasecmp(v, "yes")
               || !strcasecmp(v, "on") || !strcmp(v, "1"));
}

static void
parse_options(const char *optstr, job_opts_t *jo)
{
  int num_options;
  cups_option_t *options = NULL;
  const char *ppdfile = getenv("PPD");
  const char *v;
  char buf[256];

  num_options = cupsParseOptions(optstr ? optstr : "", 0, &options);

  /* Media type -> foo2zjs -m code for -z1 printers */
  v = get_opt("MediaType", num_options, options, ppdfile, buf, sizeof(buf),
              "Plain");
  if (!strcasecmp(v, "Transparency"))     jo->media = 2;
  else if (!strcasecmp(v, "Light"))       jo->media = 258;
  else if (!strcasecmp(v, "Heavy"))       jo->media = 261;
  else if (!strcasecmp(v, "Rough"))       jo->media = 263;
  else if (!strcasecmp(v, "Labels"))      jo->media = 265;
  else if (!strcasecmp(v, "Envelope"))    jo->media = 267;
  else if (!strcasecmp(v, "Letterhead"))  jo->media = 513;
  else if (!strcasecmp(v, "Recycled"))    jo->media = 516;
  else                                    jo->media = 1;   /* Plain */

  v = get_opt("InputSlot", num_options, options, ppdfile, buf, sizeof(buf),
              "Auto");
  jo->source = !strcasecmp(v, "Manual") ? 4 : 7;

  v = get_opt("HPDensity", num_options, options, ppdfile, buf, sizeof(buf),
              "3");
  jo->density = atoi(v);
  if (jo->density < 1 || jo->density > 5)
    jo->density = 3;

  v = get_opt("HPEconoMode", num_options, options, ppdfile, buf, sizeof(buf),
              "False");
  jo->econo = is_true(v);

  v = get_opt("HPHalftone", num_options, options, ppdfile, buf, sizeof(buf),
              "Clustered");
  if (!strcasecmp(v, "ErrorDiffusion"))
    jo->halftone = HT_DIFFUSION;
  else if (!strcasecmp(v, "Threshold"))
    jo->halftone = HT_THRESHOLD;
  else
    jo->halftone = HT_CLUSTERED;

  cupsFreeOptions(num_options, options);
}

/* ------------------------------------------------------------------------ */
/* foo2zjs child process                                                     */
/* ------------------------------------------------------------------------ */

typedef struct
{
  pid_t pid;
  FILE *fp;          /* PBM stream to foo2zjs stdin */
  unsigned w, h;     /* page bitmap size */
  unsigned xres, yres;
  int code;          /* paper code */
} child_t;

static void
sanitize(char *dst, size_t dsize, const char *src)
{
  size_t i = 0;

  if (!src)
    src = "";
  for (; *src && i + 1 < dsize; src++)
  {
    unsigned char c = (unsigned char)*src;

    dst[i++] = (c >= 0x20 && c < 0x7f && c != '"' && c != '\\') ? (char)c
                                                                 : '_';
  }
  dst[i] = '\0';
}

static int
start_child(child_t *ch, const paper_t *paper, unsigned w, unsigned h,
            unsigned xres, unsigned yres, const job_opts_t *jo,
            const char *title, const char *user)
{
  const char *prog = getenv("HP1020_FOO2ZJS");
  char a_res[32], a_dim[48], a_pap[16], a_med[16], a_src[16], a_den[16];
  char a_ul[32], a_lr[32], t_title[64], t_user[64];
  char *args[32];
  int n = 0, fds[2];
  int xdiv = (xres == 600) ? 2 : 1;   /* margins are in 1200 dpi X units */

  if (!prog || !*prog)
    prog = FOO2ZJS_PATH;

  snprintf(a_res, sizeof(a_res), "-r%ux%u", xres, yres);
  snprintf(a_dim, sizeof(a_dim), "-g%ux%u", w, h);
  snprintf(a_pap, sizeof(a_pap), "-p%d", paper->code);
  snprintf(a_med, sizeof(a_med), "-m%d", jo->media);
  snprintf(a_src, sizeof(a_src), "-s%d", jo->source);
  snprintf(a_den, sizeof(a_den), "-T%d", jo->density);
  snprintf(a_ul, sizeof(a_ul), "-u%dx%d", paper->ulx / xdiv, paper->uly);
  snprintf(a_lr, sizeof(a_lr), "-l%dx%d", paper->lrx / xdiv, paper->lry);
  sanitize(t_title, sizeof(t_title), title);
  sanitize(t_user, sizeof(t_user), user);

  args[n++] = (char *)"foo2zjs";
  args[n++] = (char *)"-z1";        /* HP LaserJet 1018/1020/1022 */
  args[n++] = (char *)"-P";         /* no START_PLANE codes */
  args[n++] = (char *)"-L0";        /* no logical clipping in stream */
  args[n++] = a_res;
  args[n++] = a_dim;
  args[n++] = a_pap;
  args[n++] = a_med;
  args[n++] = a_src;
  args[n++] = a_den;
  args[n++] = a_ul;
  args[n++] = a_lr;
  args[n++] = (char *)"-n1";        /* copies are produced by CUPS */
  args[n++] = (char *)"-d1";        /* simplex */
  if (jo->econo)
    args[n++] = (char *)"-t";       /* EconoMode on the 1020 */
  args[n++] = (char *)"-J";
  args[n++] = t_title;
  args[n++] = (char *)"-U";
  args[n++] = t_user;
  args[n] = NULL;

  {
    char cmd[512];
    int i;
    size_t len = 0;

    cmd[0] = '\0';
    for (i = 0; args[i] && len + 2 < sizeof(cmd); i++)
    {
      snprintf(cmd + len, sizeof(cmd) - len, "%s%s", i ? " " : "", args[i]);
      len = strlen(cmd);
    }
    fprintf(stderr, "DEBUG: rastertozjs: running %s (%s)\n", prog, cmd);
  }

  if (pipe(fds) < 0)
  {
    fprintf(stderr, "ERROR: rastertozjs: pipe() failed: %s\n",
            strerror(errno));
    return -1;
  }

  fflush(stderr);
  ch->pid = fork();
  if (ch->pid < 0)
  {
    fprintf(stderr, "ERROR: rastertozjs: fork() failed: %s\n",
            strerror(errno));
    close(fds[0]);
    close(fds[1]);
    return -1;
  }

  if (ch->pid == 0)
  {
    /* child: stdin = pipe, stdout = our stdout (the printer) */
    dup2(fds[0], 0);
    close(fds[0]);
    close(fds[1]);
    signal(SIGPIPE, SIG_DFL);
    execv(prog, args);
    fprintf(stderr, "ERROR: rastertozjs: cannot run %s: %s\n", prog,
            strerror(errno));
    _exit(127);
  }

  close(fds[0]);
  ch->fp = fdopen(fds[1], "w");
  if (!ch->fp)
  {
    close(fds[1]);
    return -1;
  }
  setvbuf(ch->fp, NULL, _IOFBF, 256 * 1024);
  ch->w = w;
  ch->h = h;
  ch->xres = xres;
  ch->yres = yres;
  ch->code = paper->code;
  return 0;
}

/* Close the pipe and collect the child.  Returns 0 on success. */
static int
finish_child(child_t *ch)
{
  int status = 0, rc = 0;

  if (!ch->fp)
    return 0;

  if (fclose(ch->fp) != 0)
    rc = -1;
  ch->fp = NULL;

  while (waitpid(ch->pid, &status, 0) < 0)
  {
    if (errno != EINTR)
    {
      fprintf(stderr, "ERROR: rastertozjs: waitpid() failed: %s\n",
              strerror(errno));
      return -1;
    }
  }

  if (WIFEXITED(status) && WEXITSTATUS(status) == 0)
    return rc;

  if (WIFEXITED(status))
    fprintf(stderr, "ERROR: rastertozjs: foo2zjs exited with status %d\n",
            WEXITSTATUS(status));
  else if (WIFSIGNALED(status))
    fprintf(stderr, "ERROR: rastertozjs: foo2zjs killed by signal %d\n",
            WTERMSIG(status));
  return -1;
}

/* ------------------------------------------------------------------------ */
/* Raster -> gray -> 1-bit                                                   */
/* ------------------------------------------------------------------------ */

typedef enum { IN_GRAY8, IN_KEY8, IN_RGB24, IN_BIT_BLACK1, IN_BIT_WHITE1 }
  informat_t;

static int
pick_format(const cups_page_header2_t *h, informat_t *fmt)
{
  unsigned bpc = h->cupsBitsPerColor, bpp = h->cupsBitsPerPixel;

  switch (h->cupsColorSpace)
  {
    case CUPS_CSPACE_W:
    case CUPS_CSPACE_SW:
      if (bpc == 8 && bpp == 8)  { *fmt = IN_GRAY8; return 0; }
      if (bpc == 1 && bpp == 1)  { *fmt = IN_BIT_WHITE1; return 0; }
      break;
    case CUPS_CSPACE_K:
      if (bpc == 8 && bpp == 8)  { *fmt = IN_KEY8; return 0; }
      if (bpc == 1 && bpp == 1)  { *fmt = IN_BIT_BLACK1; return 0; }
      break;
    case CUPS_CSPACE_RGB:
    case CUPS_CSPACE_SRGB:
    case CUPS_CSPACE_ADOBERGB:
      if (bpc == 8 && bpp == 24 && h->cupsColorOrder == CUPS_ORDER_CHUNKED)
      { *fmt = IN_RGB24; return 0; }
      break;
    default:
      break;
  }
  return -1;
}

/* Fill gray[0..w-1] (0 = black, 255 = white) from one raster line. */
static void
to_gray(informat_t fmt, const unsigned char *in, unsigned char *gray,
        unsigned w)
{
  unsigned x;

  switch (fmt)
  {
    case IN_GRAY8:
      memcpy(gray, in, w);
      break;
    case IN_KEY8:
      for (x = 0; x < w; x++)
        gray[x] = (unsigned char)(255 - in[x]);
      break;
    case IN_RGB24:
      for (x = 0; x < w; x++, in += 3)
        gray[x] = (unsigned char)((in[0] * 299 + in[1] * 587 + in[2] * 114
                                   + 500) / 1000);
      break;
    case IN_BIT_BLACK1:            /* 1 = black */
      for (x = 0; x < w; x++)
        gray[x] = (in[x >> 3] & (0x80 >> (x & 7))) ? 0 : 255;
      break;
    case IN_BIT_WHITE1:            /* 1 = white */
      for (x = 0; x < w; x++)
        gray[x] = (in[x >> 3] & (0x80 >> (x & 7))) ? 255 : 0;
      break;
  }
}

/* Round points to device pixels. */
static unsigned
pt2px(double pt, unsigned res)
{
  double v = pt * res / 72.0 + 0.5;

  return v > 0 ? (unsigned)v : 0;
}

/*
 * CUPS raster from a PPD usually covers only the imageable area (the page
 * minus the margins in *ImageableArea).  foo2zjs wants the whole sheet and
 * clips the margins itself, so work out the full-sheet size and where the
 * raster sits on it.
 */
static void
page_geometry(const cups_page_header2_t *h, const paper_t *paper,
              unsigned *full_w, unsigned *full_h, unsigned *x_off,
              unsigned *y_off)
{
  unsigned xres = h->HWResolution[0], yres = h->HWResolution[1];
  double pw = h->cupsPageSize[0] > 0 ? h->cupsPageSize[0] : h->PageSize[0];
  double ph = h->cupsPageSize[1] > 0 ? h->cupsPageSize[1] : h->PageSize[1];
  double left, top;
  unsigned fw = pt2px(pw, xres), fh = pt2px(ph, yres);

  /* Standard paper: use exactly the sheet size foo2zjs-wrapper uses. */
  if (paper->xdim > 0 && h->PageSize[0] <= h->PageSize[1])
  {
    fw = (unsigned)paper->xdim * xres / 1200;
    fh = (unsigned)paper->ydim * yres / 600;
  }

  *x_off = *y_off = 0;

  if (fw == 0 || fh == 0)
  {
    /* No page size in the header: treat the raster as the whole sheet. */
    *full_w = h->cupsWidth;
    *full_h = h->cupsHeight;
    return;
  }
  if (h->cupsWidth + 2 >= fw && h->cupsHeight + 2 >= fh)
  {
    /* The raster already covers the full sheet. */
    *full_w = h->cupsWidth > fw ? h->cupsWidth : fw;
    *full_h = h->cupsHeight > fh ? h->cupsHeight : fh;
    return;
  }

  /* Left edge of the raster on the sheet */
  if (h->cupsImagingBBox[2] > 0)
    left = h->cupsImagingBBox[0];
  else if (h->ImagingBoundingBox[2] > 0)
    left = h->ImagingBoundingBox[0];
  else
    left = h->Margins[0];

  /* Top edge of the raster, measured down from the top of the sheet */
  if (h->cupsImagingBBox[3] > 0)
    top = ph - h->cupsImagingBBox[3];
  else if (h->ImagingBoundingBox[3] > 0)
    top = ph - h->ImagingBoundingBox[3];
  else
    top = ph - h->Margins[1] - h->cupsHeight * 72.0 / yres;

  if (top < 0)
    top = 0;

  *x_off = pt2px(left, xres);
  *y_off = pt2px(top, yres);

  if (*x_off + h->cupsWidth > fw)
  {
    if (h->cupsWidth <= fw)
      *x_off = fw - h->cupsWidth;
    else
    {
      *x_off = 0;
      fw = h->cupsWidth;
    }
  }
  if (*y_off + h->cupsHeight > fh)
  {
    if (h->cupsHeight <= fh)
      *y_off = fh - h->cupsHeight;
    else
    {
      *y_off = 0;
      fh = h->cupsHeight;
    }
  }

  *full_w = fw;
  *full_h = fh;
}

static int
all_white(const unsigned char *gray, unsigned w)
{
  unsigned x;

  for (x = 0; x < w; x++)
    if (gray[x] != 255)
      return 0;
  return 1;
}

/* out[] must be zeroed by the caller; set bits are black. */
static void
halftone_line(int method, const unsigned char *gray, unsigned char *out,
              unsigned w, unsigned y, unsigned xscale, int *err_cur,
              int *err_next)
{
  unsigned x;

  if (method == HT_THRESHOLD)
  {
    for (x = 0; x < w; x++)
      if (gray[x] < 128)
        out[x >> 3] |= (unsigned char)(0x80 >> (x & 7));
    return;
  }

  if (method == HT_CLUSTERED)
  {
    const unsigned char *row = cluster_thresh[y & 7];

    for (x = 0; x < w; x++)
      if (gray[x] < row[(x / xscale) & 7])
        out[x >> 3] |= (unsigned char)(0x80 >> (x & 7));
    return;
  }

  /* Floyd-Steinberg, serpentine.  err arrays have w + 2 entries, offset 1. */
  memset(err_next, 0, (w + 2) * sizeof(int));
  if ((y & 1) == 0)
  {
    for (x = 0; x < w; x++)
    {
      int v = gray[x] + (err_cur[x + 1] >> 4), e;

      if (v < 128)
      {
        out[x >> 3] |= (unsigned char)(0x80 >> (x & 7));
        e = v;
      }
      else
        e = v - 255;
      err_cur[x + 2]  += e * 7;
      err_next[x]     += e * 3;
      err_next[x + 1] += e * 5;
      err_next[x + 2] += e;
    }
  }
  else
  {
    for (x = w; x-- > 0;)
    {
      int v = gray[x] + (err_cur[x + 1] >> 4), e;

      if (v < 128)
      {
        out[x >> 3] |= (unsigned char)(0x80 >> (x & 7));
        e = v;
      }
      else
        e = v - 255;
      err_cur[x]      += e * 7;
      err_next[x + 2] += e * 3;
      err_next[x + 1] += e * 5;
      err_next[x]     += e;
    }
  }
}

static const paper_t *
match_paper(const cups_page_header2_t *h)
{
  int pw = (int)h->PageSize[0], ph = (int)h->PageSize[1], i;

  if (pw > ph)                     /* landscape-fed header: compare portrait */
  {
    int t = pw; pw = ph; ph = t;
  }
  for (i = 0; papers[i].name; i++)
    if (abs(papers[i].w_pt - pw) <= 3 && abs(papers[i].h_pt - ph) <= 3)
      return &papers[i];
  return &custom_paper;
}

/* ------------------------------------------------------------------------ */

static volatile sig_atomic_t canceled = 0;

static void
on_term(int sig)
{
  (void)sig;
  canceled = 1;
}

int
main(int argc, char *argv[])
{
  int fd = 0, page = 0, rc = 0;
  cups_raster_t *ras;
  cups_page_header2_t h;
  job_opts_t jo;
  child_t ch;
  unsigned char *line = NULL, *gray = NULL, *bits = NULL;
  int *err_a = NULL, *err_b = NULL;
  size_t line_alloc = 0, w_alloc = 0;

  if (argc == 2 && !strcmp(argv[1], "--version"))
  {
    puts(VERSION_STRING);
    return 0;
  }

  if (argc < 6 || argc > 7)
  {
    fprintf(stderr, "Usage: %s job-id user title copies options [file]\n",
            argv[0]);
    return 1;
  }

  signal(SIGPIPE, SIG_IGN);
  signal(SIGTERM, on_term);

  if (argc == 7)
  {
    if ((fd = open(argv[6], O_RDONLY)) < 0)
    {
      fprintf(stderr, "ERROR: rastertozjs: cannot open %s: %s\n", argv[6],
              strerror(errno));
      return 1;
    }
  }

  memset(&jo, 0, sizeof(jo));
  memset(&ch, 0, sizeof(ch));
  parse_options(argv[5], &jo);
  init_cluster();

  fprintf(stderr,
          "DEBUG: rastertozjs: media=%d source=%d density=%d econo=%d "
          "halftone=%d\n", jo.media, jo.source, jo.density, jo.econo,
          jo.halftone);

  ras = cupsRasterOpen(fd, CUPS_RASTER_READ);
  if (!ras)
  {
    fprintf(stderr, "ERROR: rastertozjs: cannot read raster stream\n");
    return 1;
  }

  while (!canceled && cupsRasterReadHeader2(ras, &h))
  {
    informat_t fmt;
    const paper_t *paper;
    unsigned w = h.cupsWidth, ht = h.cupsHeight, y, xres, yres, xscale;
    unsigned full_w, full_h, x_off, y_off;
    size_t obytes;

    page++;
    xres = h.HWResolution[0];
    yres = h.HWResolution[1];

    fprintf(stderr,
            "DEBUG: rastertozjs: page %d: raster %ux%u px, %ux%u dpi, cs=%u "
            "bpc=%u bpp=%u bpl=%u order=%u, sheet %ux%u pt\n",
            page, w, ht, xres, yres, (unsigned)h.cupsColorSpace,
            h.cupsBitsPerColor, h.cupsBitsPerPixel, h.cupsBytesPerLine,
            (unsigned)h.cupsColorOrder, h.PageSize[0], h.PageSize[1]);

    if (w == 0 || ht == 0 || w > 30000 || ht > 30000)
    {
      fprintf(stderr, "ERROR: rastertozjs: bad page size %ux%u\n", w, ht);
      rc = 1;
      break;
    }
    if (yres != 600 || (xres != 600 && xres != 1200))
    {
      fprintf(stderr, "ERROR: rastertozjs: unsupported resolution %ux%u dpi "
              "(need 600x600 or 1200x600)\n", xres, yres);
      rc = 1;
      break;
    }
    if (pick_format(&h, &fmt) < 0)
    {
      fprintf(stderr, "ERROR: rastertozjs: unsupported raster format "
              "(colorspace %u, %u bits/color, %u bits/pixel)\n",
              (unsigned)h.cupsColorSpace, h.cupsBitsPerColor,
              h.cupsBitsPerPixel);
      rc = 1;
      break;
    }

    paper = match_paper(&h);
    xscale = xres / yres;          /* 2 at 1200x600, so dots stay round */
    page_geometry(&h, paper, &full_w, &full_h, &x_off, &y_off);

    fprintf(stderr, "DEBUG: rastertozjs: sheet %ux%u px, raster at +%u+%u, "
            "paper %s (code %d)\n", full_w, full_h, x_off, y_off,
            paper->name, paper->code);

    /* (Re)start foo2zjs when the sheet geometry changes. */
    if (!ch.fp || ch.w != full_w || ch.h != full_h || ch.xres != xres
        || ch.yres != yres || ch.code != paper->code)
    {
      if (ch.fp && finish_child(&ch) != 0)
      {
        rc = 1;
        break;
      }
      if (start_child(&ch, paper, full_w, full_h, xres, yres, &jo, argv[3],
                      argv[2]) != 0)
      {
        rc = 1;
        break;
      }
    }

    obytes = (full_w + 7) / 8;
    if (h.cupsBytesPerLine > line_alloc)
    {
      free(line);
      line_alloc = h.cupsBytesPerLine;
      line = malloc(line_alloc);
    }
    if (full_w > w_alloc)
    {
      free(gray); free(bits); free(err_a); free(err_b);
      w_alloc = full_w;
      gray = malloc(full_w);
      bits = malloc(obytes);
      err_a = malloc((full_w + 2) * sizeof(int));
      err_b = malloc((full_w + 2) * sizeof(int));
    }
    if (!line || !gray || !bits || !err_a || !err_b)
    {
      fprintf(stderr, "ERROR: rastertozjs: out of memory\n");
      rc = 1;
      break;
    }
    memset(err_a, 0, (full_w + 2) * sizeof(int));
    memset(err_b, 0, (full_w + 2) * sizeof(int));
    memset(gray, 255, full_w);       /* margins stay white */

    fprintf(stderr, "INFO: Printing page %d...\n", page);
    fprintf(ch.fp, "P4\n%u %u\n", full_w, full_h);

    /* blank rows above the imageable area */
    memset(bits, 0, obytes);
    for (y = 0; y < y_off; y++)
      fwrite(bits, 1, obytes, ch.fp);

    for (y = 0; y < ht; y++)
    {
      int ok = !canceled
               && cupsRasterReadPixels(ras, line, h.cupsBytesPerLine)
                  == h.cupsBytesPerLine;

      memset(bits, 0, obytes);

      if (!ok)
      {
        rc = 1;
        if (canceled)
          break;
        fprintf(stderr, "ERROR: rastertozjs: raster data ended early on "
                "page %d (line %u of %u)\n", page, y, ht);
        break;                       /* rest of the sheet is padded below */
      }

      to_gray(fmt, line, gray + x_off, w);
      if (all_white(gray + x_off, w))
      {
        if (jo.halftone == HT_DIFFUSION)       /* let the error decay */
        {
          int *t;

          memset(err_b, 0, (full_w + 2) * sizeof(int));
          t = err_a; err_a = err_b; err_b = t;
        }
      }
      else
      {
        int *t;

        halftone_line(jo.halftone, gray, bits, full_w, y_off + y, xscale,
                      err_a, err_b);
        t = err_a; err_a = err_b; err_b = t;
      }

      if (fwrite(bits, 1, obytes, ch.fp) != obytes)
      {
        fprintf(stderr, "ERROR: rastertozjs: write to foo2zjs failed: %s\n",
                strerror(errno));
        rc = 1;
        break;
      }
    }

    if (rc && canceled)
      break;

    /* blank rows below the imageable area (and padding after short data) */
    if (!(rc && ferror(ch.fp)))
    {
      memset(bits, 0, obytes);
      for (y = y_off + y; y < full_h; y++)
        if (fwrite(bits, 1, obytes, ch.fp) != obytes)
          break;
    }

    if (rc)
      break;

    fprintf(stderr, "PAGE: %d %u\n", page, h.NumCopies ? h.NumCopies : 1);
  }

  if (finish_child(&ch) != 0)
    rc = 1;

  cupsRasterClose(ras);
  if (fd != 0)
    close(fd);
  free(line); free(gray); free(bits); free(err_a); free(err_b);

  if (canceled)
  {
    fprintf(stderr, "INFO: rastertozjs: job canceled\n");
    return 0;
  }
  if (page == 0 && rc == 0)
    fprintf(stderr, "INFO: rastertozjs: no pages in job\n");
  else if (rc == 0)
    fprintf(stderr, "INFO: Ready to print.\n");

  return rc;
}
