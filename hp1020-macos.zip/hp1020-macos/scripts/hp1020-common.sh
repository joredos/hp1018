# hp1020-common.sh - shared functions for hp1020-fwd and hp1020-tool.
# Sourced, not executed.  POSIX sh.

HP1020_PREFIX="${HP1020_PREFIX:-/Library/Printers/HP1020}"
HP1020_CONF="${HP1020_CONF:-$HP1020_PREFIX/hp1020.conf}"
HP1020_STATE="${HP1020_STATE:-/var/db/hp1020}"
HP1020_LABEL="local.hp1020.fwloader"

# Defaults (overridden by hp1020.conf)
QUEUE="HP_LaserJet_1020"
PAUSE_WHEN_ABSENT="yes"
POLL=3
SETTLE=4
FIRMWARE=""          # empty = pick sihp1018.dl / sihp1020.dl by model
FIRMWARE_DIR="$HP1020_PREFIX/Firmware"
USB_BACKEND="${USB_BACKEND:-/usr/libexec/cups/backend/usb}"
IOREG="${IOREG:-/usr/sbin/ioreg}"

# USB IDs (decimal, as ioreg prints them): vendor HP 0x03f0,
# LaserJet 1020 = 0x2b17, LaserJet 1018 = 0x4117
USB_VID=1008
USB_PIDS="11031 16663"

if [ -r "$HP1020_CONF" ]; then
    # shellcheck disable=SC1090
    . "$HP1020_CONF"
fi

# Plain English output from CUPS tools, whatever the user's language.
LC_ALL=C
LANG=C
export LC_ALL LANG
PATH="${HP1020_TEST_PATH:+$HP1020_TEST_PATH:}/usr/sbin:/usr/bin:/bin:/sbin"
export PATH

hp_log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*"
}

# Prints an identifier of the current USB connection of the printer
# (changes on every power-on / re-plug), or nothing if it is not connected.
usb_session() {
    "$IOREG" -p IOUSB -l -w0 2>/dev/null | awk -v vid="$USB_VID" -v pids=" $USB_PIDS " '
        function flush() {
            if (v == vid && p != "" && index(pids, " " p " ") && !found) {
                print (s != "" ? s : "na") "-" l "-" a
                found = 1
            }
            v = p = s = l = a = ""
        }
        /\+-o / { flush(); next }
        /"idVendor" = /    { v = $NF }
        /"idProduct" = /   { p = $NF }
        /"sessionID" = /   { s = $NF }
        /"locationID" = /  { l = $NF }
        /"USB Address" = / { a = $NF }
        END { flush() }'
}

# The CUPS usb backend's line for the printer, e.g.
#   direct usb://HP/LaserJet%201020?serial=XXX "HP LaserJet 1020" "..." "MFG:...;FWVER:20050309;" ""
# Empty if the backend cannot see it.
device_line() {
    "$USB_BACKEND" 2>/dev/null | grep -E -i '^direct usb://.*LaserJet( |%20)10(18|20)' | head -n 1
}

# "1018" or "1020" from a device_line.
printer_model() {
    printf '%s\n' "$1" | grep -E -i -o 'LaserJet( |%20)10(18|20)' | head -n 1 | grep -E -o '10(18|20)'
}

# Firmware file for the printer in a device_line (FIRMWARE in the conf wins).
firmware_for() {
    if [ -n "$FIRMWARE" ]; then
        printf '%s\n' "$FIRMWARE"
    elif [ "$(printer_model "$1")" = 1018 ]; then
        printf '%s\n' "$FIRMWARE_DIR/sihp1018.dl"
    else
        printf '%s\n' "$FIRMWARE_DIR/sihp1020.dl"
    fi
}

device_uri() {
    printf '%s\n' "$1" | awk '{print $2}'
}

# True if the device ID in a device_line contains FWVER (firmware present).
has_firmware() {
    printf '%s\n' "$1" | grep -q 'FWVER:'
}

firmware_version() {
    printf '%s\n' "$1" | sed -n 's/.*FWVER:\([^;"]*\).*/\1/p'
}

# Sends the firmware straight to the printer through the CUPS usb backend
# (works while the queue is paused).  Must run as root.
send_firmware_backend() {
    _uri="$1"
    if [ ! -r "$FW_FILE" ]; then
        hp_log "ERROR: firmware file $FW_FILE is missing"
        return 1
    fi
    hold_active_jobs "$_uri"
    _out="${TMPDIR:-/tmp}/hp1020-usb.$$"
    DEVICE_URI="$_uri" "$USB_BACKEND" 1 root "HP1020 firmware" 1 "" "$FW_FILE" > "$_out" 2>&1 &
    _pid=$!
    HP1020_CHILD=$_pid
    _t=0
    while kill -0 "$_pid" 2>/dev/null; do
        if [ "$_t" -ge 45 ]; then
            kill "$_pid" 2>/dev/null; sleep 1; kill -9 "$_pid" 2>/dev/null
            HP1020_CHILD=""
            hp_log "ERROR: USB upload did not finish in 45 s (printer busy or held by another queue)"
            grep -v -i '^DEBUG' "$_out" | tail -n 5 | sed 's/^/    usb: /'
            rm -f "$_out"
            return 1
        fi
        sleep 1
        _t=$((_t + 1))
    done
    wait "$_pid" 2>/dev/null
    _rc=$?
    HP1020_CHILD=""
    grep -v -i '^DEBUG' "$_out" | tail -n 5 | sed 's/^/    usb: /'
    rm -f "$_out"
    [ "$_rc" = 0 ] || hp_log "usb backend exit code $_rc"
    return 0
}

# A job that started while the printer had no firmware never finishes and
# keeps the USB port busy.  Hold such jobs (CUPS stops them and keeps them
# for later), so the firmware can go out; release_held_jobs prints them again.
hold_active_jobs() {
    lpstat -v 2>/dev/null | grep -F "$1" | sed -e 's/^device for //' -e 's/:.*//' \
    | while read -r _q; do
        _job=$(lpstat -p "$_q" 2>/dev/null | sed -n 's/.* now printing \([^ ]*\)\..*/\1/p' | head -n 1)
        [ -n "$_job" ] || continue
        if lp -i "$_job" -H hold >/dev/null 2>&1; then
            mkdir -p "$HP1020_STATE" && echo "$_job" >> "$HP1020_STATE/held-jobs"
            hp_log "job $_job on $_q was holding the USB port; put on hold until the firmware is loaded"
        else
            hp_log "WARNING: job $_job on $_q holds the USB port and could not be held; cancel it: cancel $_job"
        fi
        _w=0
        while [ "$_w" -lt 20 ] && lpstat -p "$_q" 2>/dev/null | grep -q "now printing"; do
            sleep 2; _w=$((_w + 2))
        done
    done
}

release_held_jobs() {
    [ -f "$HP1020_STATE/held-jobs" ] || return 0
    while read -r _job; do
        [ -n "$_job" ] || continue
        lp -i "$_job" -H resume >/dev/null 2>&1 && hp_log "job $_job released"
    done < "$HP1020_STATE/held-jobs"
    rm -f "$HP1020_STATE/held-jobs"
}

# Fallback: submit the firmware as a raw, top-priority job on the queue.
send_firmware_queue() {
    lp -d "$QUEUE" -q 100 -o raw -t "HP1020 firmware" "$FW_FILE" >/dev/null 2>&1
}

queue_exists() {
    lpstat -p "$QUEUE" >/dev/null 2>&1
}

queue_disabled() {
    lpstat -p "$QUEUE" 2>/dev/null | grep -q " disabled"
}

queue_printing() {
    lpstat -p "$QUEUE" 2>/dev/null | grep -q "now printing"
}

# Pause the queue with a reason, but only if it is currently enabled; we then
# remember that the pause is ours so we never resume a queue the user paused.
pause_queue() {
    [ "$PAUSE_WHEN_ABSENT" = "yes" ] || return 0
    queue_exists || return 0
    queue_disabled && return 0
    if cupsdisable -r "$1" "$QUEUE" 2>/dev/null; then
        mkdir -p "$HP1020_STATE" && touch "$HP1020_STATE/paused-by-hp1020"
        hp_log "queue $QUEUE paused: $1"
    fi
}

resume_queue() {
    [ -f "$HP1020_STATE/paused-by-hp1020" ] || return 0
    if ! queue_exists; then
        rm -f "$HP1020_STATE/paused-by-hp1020"
        return 0
    fi
    if cupsenable "$QUEUE" 2>/dev/null; then
        rm -f "$HP1020_STATE/paused-by-hp1020"
        hp_log "queue $QUEUE resumed"
    fi
}

# Waits up to $1 seconds for the backend to report the printer. Prints the line.
wait_device_line() {
    _t=0
    while [ "$_t" -lt "$1" ]; do
        _l=$(device_line)
        if [ -n "$_l" ]; then
            printf '%s\n' "$_l"
            return 0
        fi
        sleep 2
        _t=$((_t + 2))
    done
    return 1
}

# Loads the firmware if the printer does not report it.
#   $1 = "force" to upload even if FWVER is reported.
# Returns 0 = loaded / already present, 1 = printer not reachable,
#         2 = sent but not confirmed, 3 = upload failed.
ensure_firmware() {
    _line=$(wait_device_line 20) || {
        hp_log "printer is on USB but the CUPS usb backend does not list it"
        return 1
    }
    if has_firmware "$_line" && [ "$1" != "force" ]; then
        hp_log "firmware already loaded (FWVER $(firmware_version "$_line"))"
        return 0
    fi
    _uri=$(device_uri "$_line")
    FW_FILE=$(firmware_for "$_line")
    hp_log "LaserJet $(printer_model "$_line"): uploading firmware $(basename "$FW_FILE") to $_uri"
    _before=$(usb_session)
    if ! send_firmware_backend "$_uri"; then
        return 3
    fi

    # macOS's usb backend rebuilds the device ID from MFG/MDL/SERN only, so
    # FWVER is usually not visible there.  After a good upload the printer
    # restarts its controller and re-appears on USB with a new session;
    # take that (or FWVER) as confirmation.
    _t=0
    while [ "$_t" -lt 30 ]; do
        _now=$(usb_session)
        if has_firmware "$(device_line)"; then
            hp_log "firmware loaded (FWVER reported)"
            return 0
        fi
        if [ -n "$_now" ] && [ "$_now" != "$_before" ]; then
            hp_log "firmware loaded (printer restarted on USB)"
            return 0
        fi
        sleep 3
        _t=$((_t + 3))
    done
    hp_log "firmware sent; no confirmation from the printer (normal on macOS). Assuming it is loaded."
    return 2
}
