#!/bin/sh
#
# build.sh - compile the HP LaserJet 1020 driver and prepare the firmware.
#
#   ./build.sh                     build into ./build and download the firmware
#   ./build.sh --firmware FILE     use a local sihp1020.dl or sihp1020.img
#   ./build.sh --clean             remove ./build
#
# Needs a C compiler (on macOS: xcode-select --install) and, unless
# --firmware is given, internet access to GitHub.
#
set -eu

cd "$(dirname "$0")"
TOP=$(pwd)
OUT="$TOP/build"
SRC="$TOP/src"

# Firmware image from the foo2zjs mirror, pinned to one commit + checksum.
FW_COMMIT="e04290de6b7a30d588f3411fd9834618e09f7b9b"
FW_BASE="https://raw.githubusercontent.com/koenkooi/foo2zjs/$FW_COMMIT"
# model  image sha256  converted .dl sha256
FW_LIST="1020 9d10d8e84a9577f268aac6336ed18cf9235e6f732c1f68e8913c787db60106ce 133b21fe0cb24bfe53e2eff2f00a82cce4beb970749049661ade7a6801f22663
1018 d668cfa392aadca4675d8156ac6191176e04a56591d54034f42691e4fd2f15af 5aeaca1afb6c9e0baa8f20b70b8b5c49701b6b5a97f1014ad750227d71548cf6"

FILTER_PATH="/Library/Printers/HP1020/Filter/foo2zjs"

say()  { printf '==> %s\n' "$*"; }
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

sha256() {
    if command -v shasum >/dev/null 2>&1; then
        shasum -a 256 "$1" | awk '{print $1}'
    else
        sha256sum "$1" | awk '{print $1}'
    fi
}

FIRMWARE_SRC=""
while [ $# -gt 0 ]; do
    case "$1" in
        --firmware) [ $# -ge 2 ] || fail "--firmware needs a file"; FIRMWARE_SRC="$2"; shift 2 ;;
        --clean)    rm -rf "$OUT"; say "removed $OUT"; exit 0 ;;
        -h|--help)  sed -n '3,12p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *)          fail "unknown option: $1" ;;
    esac
done

# ---------------------------------------------------------------- compiler --
OS=$(uname -s)
ARCH=$(uname -m)
CC="${CC:-cc}"
CFLAGS="-O2 -Wall -Wno-unused-but-set-variable -Wno-deprecated-declarations"
ARCHFLAGS=""

if [ "$OS" = Darwin ]; then
    xcode-select -p >/dev/null 2>&1 \
        || fail "the Command Line Tools are missing. Run:  xcode-select --install   then run this script again."
    SDK=$(xcrun --show-sdk-path 2>/dev/null || true)
    if [ -n "$SDK" ] && [ ! -f "$SDK/usr/include/cups/raster.h" ]; then
        fail "the macOS SDK has no CUPS headers ($SDK/usr/include/cups/raster.h). Reinstall the Command Line Tools."
    fi
    [ "$ARCH" = arm64 ] && ARCHFLAGS="-arch arm64"
fi
command -v "$CC" >/dev/null 2>&1 || fail "no C compiler ($CC)"

mkdir -p "$OUT"

say "compiling foo2zjs (ZjStream/JBIG encoder)"
# shellcheck disable=SC2086
$CC $CFLAGS $ARCHFLAGS -o "$OUT/foo2zjs" \
    "$SRC/foo2zjs/foo2zjs.c" "$SRC/foo2zjs/jbig.c" "$SRC/foo2zjs/jbig_ar.c"

say "compiling zjsdecode (diagnostics) and arm2hpdl (firmware converter)"
# shellcheck disable=SC2086
$CC $CFLAGS $ARCHFLAGS -o "$OUT/zjsdecode" \
    "$SRC/foo2zjs/zjsdecode.c" "$SRC/foo2zjs/jbig.c" "$SRC/foo2zjs/jbig_ar.c"
# shellcheck disable=SC2086
$CC $CFLAGS $ARCHFLAGS -o "$OUT/arm2hpdl" "$SRC/foo2zjs/arm2hpdl.c"

say "compiling rastertozjs (CUPS filter)"
# shellcheck disable=SC2086
$CC $CFLAGS $ARCHFLAGS -DFOO2ZJS_PATH="\"$FILTER_PATH\"" -o "$OUT/rastertozjs" \
    "$SRC/rastertozjs.c" -lcups

if [ "$OS" = Darwin ]; then
    for b in foo2zjs zjsdecode arm2hpdl rastertozjs; do
        codesign --force --sign - "$OUT/$b" >/dev/null 2>&1 || true
        printf '    %-12s %s\n' "$b" "$(lipo -archs "$OUT/$b" 2>/dev/null || echo '?')"
    done
fi

# ---------------------------------------------------------------- firmware --
# Both firmwares are prepared (1018 and 1020); the loader picks one by model.
# --firmware FILE replaces the one whose model is in the file name
# (sihp1018.* -> 1018, anything else -> 1020).
echo "$FW_LIST" | while read -r model img_sha dl_sha; do
    FW="$OUT/sihp$model.dl"
    src=""
    if [ -n "$FIRMWARE_SRC" ]; then
        case "$FIRMWARE_SRC" in
            *1018*) [ "$model" = 1018 ] && src="$FIRMWARE_SRC" ;;
            *)      [ "$model" = 1020 ] && src="$FIRMWARE_SRC" ;;
        esac
    fi
    if [ -n "$src" ]; then
        [ -r "$src" ] || fail "cannot read $src"
        case "$src" in
            *.img|*.IMG)
                say "converting $src to sihp$model.dl"
                "$OUT/arm2hpdl" "$src" > "$FW.tmp" || fail "arm2hpdl failed"
                mv "$FW.tmp" "$FW" ;;
            *)  cp "$src" "$FW" ;;
        esac
    elif [ -s "$FW" ] && [ "$(sha256 "$FW")" = "$dl_sha" ]; then
        say "firmware sihp$model.dl already prepared"
    else
        say "downloading the HP LaserJet $model firmware image"
        curl -fsSL --retry 3 --connect-timeout 20 -o "$OUT/sihp$model.img" "$FW_BASE/sihp$model.img" \
            || fail "download failed. Get sihp$model.img or .dl yourself and run: ./build.sh --firmware FILE"
        got=$(sha256 "$OUT/sihp$model.img")
        [ "$got" = "$img_sha" ] || fail "sihp$model.img checksum mismatch ($got)"
        "$OUT/arm2hpdl" "$OUT/sihp$model.img" > "$FW.tmp" || fail "arm2hpdl failed"
        mv "$FW.tmp" "$FW"
        rm -f "$OUT/sihp$model.img"
    fi
    head -c 64 "$FW" | grep -q "ENTER LANGUAGE=ACL" \
        || fail "$FW does not look like HP LaserJet firmware (.dl)"
    if [ "$(sha256 "$FW")" = "$dl_sha" ]; then
        say "firmware sihp$model.dl OK (checksum verified)"
    else
        say "firmware sihp$model.dl OK (your file; checksum differs from the reference)"
    fi
done || exit 1

say "build complete: $OUT"
