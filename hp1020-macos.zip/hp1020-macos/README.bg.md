# Драйвер за HP LaserJet 1018 / 1020 (USB) за macOS 27 на Apple silicon

Native **arm64** драйвер за HP LaserJet **1018** и **1020** за Mac с чип M1/M2/M3/M4 — без Rosetta, без Ghostscript, без изключване на SIP.

HP никога не е издавал драйвер за 1020 за Apple silicon, а macOS 27 вече не инсталира Rosetta автоматично, така че старите Intel драйвери спират да работят. Този пакет се компилира на вашия Mac от изходен код и използва вградения в macOS растеризатор.

---

## Как работи

HP LaserJet 1020 е „host-based“ принтер: не разбира PostScript/PCL и **няма фърмуер във флаш паметта си** — фърмуерът трябва да се качва в RAM на принтера при всяко включване.

```
Приложение → PDF → cgpdftoraster (macOS) → rastertozjs → foo2zjs → usb backend → принтер
                                             (този пакет)  (ZjStream/JBIG)

USB включване → hp1020-fwd (LaunchDaemon) → проверка FWVER → качване на sihp1020.dl
```

| Компонент | Какво прави |
|---|---|
| `rastertozjs` | CUPS филтър (C, arm64). Приема растера от macOS, сглобява цялата страница, растерира сивите тонове (clustered dot / error diffusion / праг) и подава 1-битови страници на `foo2zjs`. |
| `foo2zjs` | Проверен open-source кодер (GPL) — превръща страниците в ZjStream с JBIG компресия, езика на 1020. |
| `HP-LaserJet-1020-arm64.ppd` | Описание на принтера: формати хартия, полета, резолюция, опции. |
| `hp1020-fwd` | LaunchDaemon. Следи USB шината (1018 = `03f0:4117`, 1020 = `03f0:2b17`); при всяко ново свързване разпознава модела, пита принтера дали има фърмуер (поле `FWVER` в IEEE-1284 ID) и ако няма — качва правилния: `sihp1018.dl` за 1018, `sihp1020.dl` за 1020. Докато принтерът е изключен или без фърмуер, държи опашката на пауза, за да не се загубят задания. |
| `hp1020-tool` | Помощна команда: статус, тест без хартия, тестов печат, ръчно качване на фърмуер, логове. |

---

## Изисквания

- Mac с Apple silicon (вашият M2 Pro е ОК), macOS 27
- Xcode **Command Line Tools** (компилатор + SDK)
- Интернет при инсталацията (за изтегляне на фърмуера от GitHub) — или собствен файл `sihp1020.dl`/`sihp1020.img`
- USB кабел (USB-B ↔ USB-C адаптер/кабел за MacBook)

---

## Инсталация

**1. Command Line Tools** (ако още не са инсталирани):

```sh
xcode-select --install
```

Потвърдете в прозореца, който се отваря, и изчакайте да приключи.

**2. Включете принтера** в USB порта и го пуснете (бутон за захранване). Ако macOS сам предложи да го добави — откажете или игнорирайте.

**3. Разархивирайте пакета и пуснете инсталатора** в Terminal:

```sh
cd ~/Downloads
unzip hp1020-macos.zip        # ако Safari вече го е разархивирал, пропуснете
cd hp1020-macos
sudo sh ./install.sh
```

Инсталаторът:
1. компилира драйвера за arm64;
2. изтегля фърмуерите за 1018 и 1020 (закачени към конкретен commit в GitHub, SHA-256 се проверява) и ги конвертира в `sihp1018.dl` и `sihp1020.dl`;
3. инсталира файловете в `/Library/Printers/HP1020/` и PPD-то в `/Library/Printers/PPDs/Contents/Resources/`;
4. стартира `hp1020-fwd` като LaunchDaemon;
5. създава опашка за печат **HP_LaserJet_1020** с хартия A4;
6. изчаква фърмуерът да се зареди и показва статус.

Опции:

```sh
sudo sh ./install.sh --paper Letter             # друг формат по подразбиране
sudo sh ./install.sh --firmware ~/sihp1018.dl   # собствен фърмуер (.dl/.img; името определя модела 1018/1020)
sudo sh ./install.sh --no-queue                 # без създаване на опашка
sudo sh ./install.sh --queue HP1020             # друго име на опашката
```

**4. Разрешете фоновия процес.** macOS ще покаже известие „Background Items Added“. Ако някога се окаже изключен: **System Settings → General → Login Items & Extensions** → разрешете `hp1020-fwd`.

> Съобщението `lpadmin: Printer drivers are deprecated…` е нормално — CUPS предупреждава, че драйверите с PPD един ден ще отпаднат. Към macOS 27 работят.

---

## Тестване

Изпълнявайте в този ред — всяка стъпка проверява по-голяма част от веригата.

### 1. Статус (без печат)

```sh
sudo hp1020-tool status
```

Очаквано:

```
  ok      /Library/Printers/HP1020/Filter/rastertozjs [arm64]
  ok      /Library/Printers/HP1020/Filter/foo2zjs [arm64]
  ...
  state = running
  printer present on USB (session ...)
  model: HP LaserJet 1018 (firmware file sihp1018.dl)
  URI: usb://HP/LaserJet%201018?serial=...
  firmware: LOADED (FWVER 20050309)
  printer HP_LaserJet_1020 is idle.  enabled since ...
```

При зареждане на фърмуера принтерът издава звук и светлините му мигат за няколко секунди — това е нормално.

### 2. Тест без хартия (суха проба)

```sh
hp1020-tool test-dry
```

Пуска **целия драйвер** върху тестовата страница (2 страници A4) чрез `cupsfilter` — същата верига като при истински печат, но резултатът отива във файл. После декодира генерирания ZjStream обратно и записва PNG прегледи в `~/hp1020-test/`, като отваря първия в Preview.

Очаквано:

```
OK: ~100000 bytes of ZjStream, 2 page(s), paper a4, 600 dpi
  sheet 4960x7016 px, raster at +96+96, paper A4 (code 9)
```

Това, което виждате в Preview, е точно това, което принтерът ще получи. Може да подадете и собствен файл и опции:

```sh
hp1020-tool test-dry ~/Documents/файл.pdf -o PageSize=A5 -o HPHalftone=ErrorDiffusion
```

### 3. Тестов печат

```sh
hp1020-tool test-print
```

Отпечатва 2-страничната тестова страница и следи заданието. Проверете на хартията:

- **Рамката** по ръба на печатната област (≈4 мм от ръба на листа) се вижда от всичките 4 страни, ъгловите маркери също.
- **Скалата 0–100 %** — 11 различими нива; 0 % е бяло, 100 % плътно черно.
- **Преходът** е плавен, без ивици.
- **Линиите** — дори 0,1 pt се вижда като тънка линия.
- **Текст** — 5 pt е четим, кирилицата е наред.
- **Страница 2** излиза → многостраничният печат работи.

### 4. Печат от приложение

Отворете произволен документ → **File → Print** (⌘P) → принтер **HP LaserJet 1020** → Print. Опциите на драйвера са в падащото меню на диалога, панел **Printer Features** (групи General и Print Quality); Media Type и Media Source са и в **Paper Handling / Media & Quality** според версията на диалога.

---

## Опции на драйвера

| Опция | Стойности | По подразбиране |
|---|---|---|
| Media Size | A4, Letter, Legal, Executive, A5, A6, B5 (JIS/ISO), пликове #10/DL/C5/Monarch, пощенски картички, 16K | A4 |
| Resolution | 600 dpi; FastRes 1200 (1200×600) | 600 dpi |
| Media Source | Main Tray; Priority Slot (Manual Feed) | Main Tray |
| Media Type | Plain, Light, Heavy/Cardstock, Rough, Labels, Envelope, Transparency, Letterhead, Recycled | Plain |
| Print Density | 1 (най-светло) … 5 (най-тъмно) | 3 |
| EconoMode | Off / On (пести тонер) | Off |
| Halftoning | Clustered dot (за лазер) / Error diffusion (повече детайл в снимки) / Threshold (само текст) | Clustered dot |

Постоянни настройки за опашката (пример):

```sh
sudo lpadmin -p HP_LaserJet_1020 -o HPDensity=4 -o HPEconoMode=True
```

---

## Отстраняване на проблеми

| Симптом | Причина / решение |
|---|---|
| `model:` показва грешен модел | Ръчно: `FIRMWARE="/Library/Printers/HP1020/Firmware/sihp1018.dl"` в `/Library/Printers/HP1020/hp1020.conf`, после `sudo launchctl kickstart -k system/local.hp1020.fwloader`. |
| `firmware: NOT loaded` | Изчакайте 10 сек. след включване. После `sudo hp1020-tool loadfw`. Логът: `hp1020-tool log`. |
| Опашката е **Paused** | Нормално, докато принтерът е изключен — заданията чакат и тръгват сами след включване и зареждане на фърмуера. Ако не тръгнат: `sudo hp1020-tool loadfw`, после `sudo cupsenable HP_LaserJet_1020`. Изключване на автоматичната пауза: `PAUSE_WHEN_ABSENT="no"` в `/Library/Printers/HP1020/hp1020.conf`. |
| `printer NOT found on USB` | Кабел, хъб, захранване. Проверка: `ioreg -p IOUSB | grep -i laserjet`. Ако е през USB хъб/док, опитайте директно. |
| Daemon `NOT loaded` | `sudo launchctl bootstrap system /Library/LaunchDaemons/local.hp1020.fwloader.plist` и разрешете `hp1020-fwd` в Login Items & Extensions. |
| Заданието „изчезва“, нищо не излиза | Фърмуерът не е бил зареден. `sudo hp1020-tool status`; при нужда `sudo hp1020-tool loadfw --force` и печат отново. |
| `Filter failed` | `sudo hp1020-tool debug on`, печат отново, `sudo hp1020-tool log`. Търсете редове с `rastertozjs` — там е точната причина (формат на растера, резолюция). После `sudo hp1020-tool debug off`. |
| Две опашки за 1020 | macOS може сам да е добавил една. Изтрийте другата в System Settings → Printers & Scanners. |
| Добавили сте принтера ръчно от System Settings | Работи (изберете „HP LaserJet 1020 (arm64, foo2zjs)“ от *Use → Select Software*), но авто-паузата е само за опашката от `hp1020.conf`. По-добре: `sudo hp1020-tool add-queue`. |
| Твърде тъмни/светли сиви | Print Density 2 или 4; за снимки опитайте Error diffusion. |

Полезни команди:

```sh
hp1020-tool status                # пълен статус (с sudo — и състояние на фърмуера)
hp1020-tool log                   # лог на daemon-а + грешки от CUPS
lpstat -p HP_LaserJet_1020        # състояние на опашката
cancel -a HP_LaserJet_1020        # изтрива всички чакащи задания
sudo launchctl kickstart -k system/local.hp1020.fwloader   # рестарт на daemon-а
```

---

## Деинсталиране

```sh
cd hp1020-macos
sudo sh ./uninstall.sh               # маха драйвер, daemon и опашка
sudo sh ./uninstall.sh --keep-queue  # оставя опашката
```

---

## Файлове

```
/Library/Printers/HP1020/Filter/rastertozjs, foo2zjs      CUPS филтър + кодер (arm64)
/Library/Printers/HP1020/Firmware/sihp1018.dl, sihp1020.dl   фърмуери (избират се по модел)
/Library/Printers/HP1020/bin/hp1020-fwd, hp1020-tool, ...
/Library/Printers/HP1020/hp1020.conf                      настройки на daemon-а
/Library/Printers/PPDs/Contents/Resources/HP-LaserJet-1020-arm64.ppd.gz
/Library/LaunchDaemons/local.hp1020.fwloader.plist
/Library/Logs/HP1020/hp1020-fwd.log
/usr/local/bin/hp1020-tool → /Library/Printers/HP1020/bin/hp1020-tool
```

Изходен код в пакета: `src/rastertozjs.c` (филтърът), `src/foo2zjs/` (foo2zjs, JBIG-KIT, zjsdecode, arm2hpdl), `scripts/`, `ppd/`, `tools/` (генератори на PPD и тестовата страница).

---

## Какво е проверено и какво не

Проверено при разработката (на Linux с CUPS 2.4 и същия код): компилиране без предупреждения; PPD минава `cupstestppd`; пълна верига PDF → растер → `rastertozjs` → `foo2zjs` за всички 16 формата при 600 и 1200×600 dpi; всички опции стигат до принтерния поток; декодиране на изхода със `zjsdecode` и визуална проверка; входни растери 1-bit / 8-bit / RGB, смесени формати в едно задание, грешни входове; логиката на `hp1020-fwd` в 10 сценария (изключване/включване, рестарт на Mac, потребителска пауза, неуспешно качване); инсталатор/деинсталатор и печат през реален `cupsd` към файл.

**Не е проверено на реален Mac с macOS 27 и физически принтер.** Частите, които зависят от Apple (растерът от `cgpdftoraster`, USB backend-ът на macOS, одобряването на фоновия процес), следват документираните механизми на CUPS, но първият истински тест е при вас. Стъпки 1–3 от „Тестване“ са направени така, че при проблем да покажат точно на кое място е. Ако нещо не тръгне, пратете ми изхода на `sudo hp1020-tool status` и `sudo hp1020-tool log`.

Името на опашката остава `HP_LaserJet_1020` и за 1018 — няма значение за работата; друго име: `--queue`.

Ограничения: няма автоматичен двустранен печат (1020 няма дуплекс); няма отчитане на нивото на тонера.

---

## Лицензи

- `rastertozjs`, скриптовете и PPD-то: GPL-2.0-or-later.
- `foo2zjs`, `zjsdecode`, `arm2hpdl` — © Rick Richardson, GPL-2.0-or-later; JBIG-KIT — © Markus Kuhn, GPL. Виж `src/foo2zjs/COPYING`.
- Фърмуерите `sihp1018`/`sihp1020` са собственост на HP. Не е включен в пакета — инсталаторът го изтегля от публичното огледало на foo2zjs (`github.com/koenkooi/foo2zjs`) и проверява контролната сума.
